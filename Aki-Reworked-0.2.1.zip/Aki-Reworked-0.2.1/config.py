#_________settings__________
settings = {
	'TOKEN': '##################WRITE UR TOKEN PLZ#######################', #bot token
	'BOT NAME': 'Aki', #bot name
	'ID': '722197932916473876', #bot id
	'OWNER ID': 551653500216672256, #owner id
	'PREFIX': '$', #bot prefix
	'OWNER':'Toil#5605', #discord owner name
	'OWNER PING':'<@551653500216672256>', #owner ping
	'SPECIAL THANKS':'Fsoky#9610', #thanks
	'DEBUG': True,
	'BACKUPS': True
}
#_________color_____________
cogs_color = {
	'AVATAR COLOR': 0x0c0c0c,
	'RANDOM COLOR': 0xca3a3a,
	'RANDOM COLOR ERROR': 0xc9a638,
	'TIME COLOR': 0x4a8f62,
	'WIKIPEDIA COLOR': 0x00ffff,
	'WIKIPEDIA COLOR ERROR': 0xc9a638,
	'BOT COLOR EXAMPLE': 0xca3a3a,
	'BOT COLOR ERROR': 0xc9a638,
	'HELP NONE COLOR': 0x2285f5,
	'AHELP COLOR': 0x2285f5,
	'CLEAR ALL EMOJI COLOR EXAMPLE': 0xca3a3a,
	'CLEAR EMOJI COLOR EXAMPLE': 0xca3a3a,
	'DELETE EMOJI COLOR EXAMPLE': 0xca3a3a,
	'ADD EMOJI COLOR EXAMPLE': 0xca3a3a,
	'BOT INFO COLOR': 0x2285f5,
	'SERVER INFO COLOR': 0x2285f5,
	'MCACH COLOR': 0xe00055,
	'UPTIME COLOR': 0xca3a3a,
	'PING COLOR': 0xca3a3a,
	'REVERSE COLOR': 0xca3a3a,
	'TRANSLIT COLOR EXAMPLE': 0xca3a3a,
	'TRANSLIT COLOR ERROR': 0xc9a638,
	'LAYOUT COLOR EXAMPLE': 0xca3a3a,
	'LAYOUT COLOR ERROR': 0xc9a638,
	'ON GUILD JOIN LOG': 0x32ea96,
	'ON GUILD LEAVE LOG': 0x32ea96,
	'FUCK U NOT USER': 0x6bf810, #example
	'FUCK U': 0xca3a3a,
	'HELP COLOR': 0x2285f5, #delete later
}
#_________quick messages____
quick_messages = {
    #logs
	'UNKNOWN ERROR LOG': '[Logs:error] Произошла неизвестная ошибка! |',
	'UNKNOWN ERROR': 'Произошла неизвестная ошибка!',
	'UNKNOWN ERROR EN': 'An unknown error has occurred!',
	'BOT STATUS LOG': '[Logs:owner] Статус бота был успешно сменен на:',
	'THIRD PARTY SYM ERROR': 'Ошибка! Были найдены сторонние символы!',
	'THIRD PARTY SYM ERROR EN': 'Mistake! Third party symbols were found!',
	'THIRD PARTY SYM ERROR LOG': '[Logs:error] Ошибка! Были найдены сторонние символы! |',
    #other
	'COPYRIGHT RU': 'Copyright © 2020 Aki | Все права защищены.',
	'COPYRIGHT EN': 'Copyright © 2020 Aki | All rights reserved.',
}
#_________other settings____
other_settings = {
	'COMMAND VALUE': '21',
	'CURRENT PATCH': '0.2.1',
	'CURRENT VERSION': 'Alpha',
}
#_________fast link_________
fast_link = {
	'TIME MSC': 'https://time100.ru/',
	'TIME CET': 'https://time.is/CET',
	'STREAM URL': 'https://www.twitch.tv/bratishkinoff',
	'WIKIPEDIA IMG': 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Wikipedia-logo-v2.svg/1200px-Wikipedia-logo-v2.svg.png',
	'MCACH': 'https://minecraftskinstealer.com/achievement/',
	'DISCORD URL': 'https://discord.gg/Vh3VcaEv23',
	'DISCORD': 'https://discord.com'
}
#_________emoji_____________
emoji = {
	'ping_emoji': '🟩🔳🔳🔳🔳'
}
#_________channels__________
channels = {
	'LOG JOIN CHANNEL': 782619819979046943,
	'LOG LEAVE CHANNEL': 782619819979046943,
}