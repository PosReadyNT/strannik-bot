colors = {
        "default" : {
            "avatar"        :   0x0c0c0c,
            "random"        :   0xca3a3a,
            "time"          :   0x4a8f62,
            "wikipedia"     :   0x00ffff,
            "help"          :   0x2285f5,
            "ahelp"         :   0x2285f5,
            "bot info"      :   0x2285f5,
            "server info"   :   0x2285f5,
            "mcach"         :   0xe00055,
            "uptime"        :   0xca3a3a,
            "ping"          :   0xca3a3a,
            "reverse"       :   0xca3a3a,
            "fuck you"      :   0xca3a3a,
            "cogs"          :   0xca3a3a
        },
        "error" : {
            "random"        :   0xc9a638,
            "wikipedia"     :   0xc9a638,
            "temp status"   :   0xca3a3a,
            "translit"      :   0xc9a638,
            "fuck you"      :   0x6bf810,
            "layout"        :   0xca3a3a,
            "mcach"         :   0x6bf810
        },
        "example" : {
            "temp status"   :   0xca3a3a,
            "cls all emoji" :   0xca3a3a,
            "clear emoji"   :   0xca3a3a,
            "delete emoji"  :   0xca3a3a,
            "add emoji"     :   0xca3a3a,
            "translit"      :   0xca3a3a,
            "layout"        :   0xca3a3a,
            "press f"       :   0x6bf810
        },
        "logs" : {
            "guild join"    :   0x32ea96,
            "guild leave"   :   0x32ea96
        }
}